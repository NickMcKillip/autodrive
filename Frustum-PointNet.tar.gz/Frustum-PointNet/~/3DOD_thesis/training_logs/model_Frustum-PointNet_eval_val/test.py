
import pickle

with open('eval_dict_val.pkl', 'rb') as p_f:
    data = pickle.load(p_f)

