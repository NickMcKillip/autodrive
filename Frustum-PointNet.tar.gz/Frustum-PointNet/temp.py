import rospy
import numpy as np
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2
import ros_numpy

def callback(msg):
    x = []
    for point in sensor_msgs.point_cloud2.read_points(msg, skip_nans=True):
        x.append([point[0], point[1], point[2]])

    x = np.array(x)
    print(x.shape)
rospy.Subscriber('/velodyne_points', PointCloud2, callback, queue_size = 1)

rospy.init_node('test')
rospy.spin()
